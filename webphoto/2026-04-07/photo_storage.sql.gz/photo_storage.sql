-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: photo_storage
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_logs`
--

DROP TABLE IF EXISTS `admin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_logs` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `admin_logs_admin_idx` (`admin_id`,`created_at`),
  KEY `admin_logs_target_idx` (`target_type`,`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_logs`
--

LOCK TABLES `admin_logs` WRITE;
/*!40000 ALTER TABLE `admin_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album_share_tokens`
--

DROP TABLE IF EXISTS `album_share_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `album_share_tokens` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `album_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `allow_like` tinyint(1) NOT NULL DEFAULT '1',
  `allow_comment` tinyint(1) NOT NULL DEFAULT '1',
  `allow_download` tinyint(1) NOT NULL DEFAULT '1',
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `album_share_tokens_token_unique` (`token`),
  UNIQUE KEY `share_tokens_token_idx` (`token`),
  KEY `share_tokens_album_idx` (`album_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album_share_tokens`
--

LOCK TABLES `album_share_tokens` WRITE;
/*!40000 ALTER TABLE `album_share_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `album_share_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `albums`
--

DROP TABLE IF EXISTS `albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `albums` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `cover_key` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cover_storage_backend` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `drive_folder_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `image_count` int NOT NULL DEFAULT '0',
  `total_bytes` bigint NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `max_favorites` int DEFAULT '20',
  PRIMARY KEY (`id`),
  KEY `albums_user_idx` (`user_id`,`created_at`),
  KEY `albums_public_idx` (`is_public`,`is_active`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albums`
--

LOCK TABLES `albums` WRITE;
/*!40000 ALTER TABLE `albums` DISABLE KEYS */;
/*!40000 ALTER TABLE `albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_logs`
--

DROP TABLE IF EXISTS `app_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_logs` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` enum('TRACE','DEBUG','INFO','WARN','ERROR','FATAL') COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` text COLLATE utf8mb4_unicode_ci,
  `stack` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `app_logs_level_created_idx` (`level`,`created_at`),
  KEY `app_logs_created_idx` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_logs`
--

LOCK TABLES `app_logs` WRITE;
/*!40000 ALTER TABLE `app_logs` DISABLE KEYS */;
INSERT INTO `app_logs` VALUES ('01KNM60GHG84762DMVVHGN2WV2','FATAL','Uncaught exception: Socket closed unexpectedly','{\"errorName\":\"SocketClosedUnexpectedlyError\"}','Error: Socket closed unexpectedly\n    at Socket.<anonymous> (/app/node_modules/@redis/client/dist/lib/client/socket.js:232:33)\n    at Object.onceWrapper (node:events:639:26)\n    at Socket.emit (node:events:524:28)\n    at TCP.<anonymous> (node:net:343:12)','2026-04-07 14:37:12'),('01KNM60GHX4CGPH48D58E9N68H','FATAL','Uncaught exception: Socket closed unexpectedly','{\"errorName\":\"SocketClosedUnexpectedlyError\"}','Error: Socket closed unexpectedly\n    at Socket.<anonymous> (/app/node_modules/@redis/client/dist/lib/client/socket.js:232:33)\n    at Object.onceWrapper (node:events:639:26)\n    at Socket.emit (node:events:524:28)\n    at TCP.<anonymous> (node:net:343:12)','2026-04-07 14:37:12'),('01KNM60MBEZC8TKR2YJRMAA4HD','INFO','[Worker] Connecting to Redis...','{\"source\":\"worker\"}',NULL,'2026-04-07 14:37:16'),('01KNM60MDHD74FVW1Y2C4V3M9F','INFO','[Worker] Starting workers...','{\"source\":\"worker\"}',NULL,'2026-04-07 14:37:16'),('01KNM60MGC5FS4WKC68C93Q7XE','INFO','[Worker] All workers started: image-process(3), image-expiry, storage-monitor, email-send(5), drive-import(2)','{\"source\":\"worker\"}',NULL,'2026-04-07 14:37:16'),('01KNM60P81JFFBZTQRKE38N58A','INFO','Storage: Cloudflare R2',NULL,NULL,'2026-04-07 14:37:18'),('01KNM60P9TBGV2P8T0KJRNJGJB','WARN','GOOGLE_SERVICE_ACCOUNT_JSON not set — Google Drive integration disabled',NULL,NULL,'2026-04-07 14:37:18'),('01KNM60PA1X02WKN79JY7ZNBF6','INFO','API server running on port 4000',NULL,NULL,'2026-04-07 14:37:18'),('01KNM60PRJ2B8Y9TJDVWQF08JF','INFO','Socket.io server running on port 4001',NULL,NULL,'2026-04-07 14:37:18'),('01KNM60Q2FPW00P14WSJXHQKGV','INFO','Restart notification email sent to admin',NULL,NULL,'2026-04-07 14:37:19'),('01KNM60SMXG3DNVXV5EVW8BM5G','INFO','[Worker] Shutting down...','{\"source\":\"worker\"}',NULL,'2026-04-07 14:37:21'),('01KNM616Y8JC08450J3EG20E41','INFO','[Worker] Connecting to Redis...','{\"source\":\"worker\"}',NULL,'2026-04-07 14:37:35'),('01KNM6170GW66175KE1NNRX1HJ','INFO','[Worker] Starting workers...','{\"source\":\"worker\"}',NULL,'2026-04-07 14:37:35'),('01KNM6172ADKAC3VK5GPRWT6S1','INFO','[Worker] All workers started: image-process(3), image-expiry, storage-monitor, email-send(5), drive-import(2)','{\"source\":\"worker\"}',NULL,'2026-04-07 14:37:35'),('01KNM6179S4WFQB01VE0E9MG3D','INFO','Storage: Cloudflare R2',NULL,NULL,'2026-04-07 14:37:35'),('01KNM617AGJ5EWJ8H7DCR7XXSK','WARN','GOOGLE_SERVICE_ACCOUNT_JSON not set — Google Drive integration disabled',NULL,NULL,'2026-04-07 14:37:35'),('01KNM617AQS09YBKNYPM7ZCYRX','INFO','API server running on port 4000',NULL,NULL,'2026-04-07 14:37:35'),('01KNM617JHZA49BKHCT546BEPW','INFO','Socket.io server running on port 4001',NULL,NULL,'2026-04-07 14:37:36'),('01KNM617VXB01ZBVHW5JV58WTX','INFO','Restart notification email sent to admin',NULL,NULL,'2026-04-07 14:37:36'),('01KNM678ZXV75MEEKJ8X4S2JD5','INFO','[Worker] Connecting to Redis...','{\"source\":\"worker\"}',NULL,'2026-04-07 14:40:54'),('01KNM6793840KMCGEGSH4HYJVN','INFO','[Worker] Starting workers...','{\"source\":\"worker\"}',NULL,'2026-04-07 14:40:54'),('01KNM67963J06XRAPAVD3T70GC','INFO','[Worker] All workers started: image-process(3), image-expiry, storage-monitor, email-send(5), drive-import(2)','{\"source\":\"worker\"}',NULL,'2026-04-07 14:40:54'),('01KNM67K6YC9KY0PA5T7AXV36P','INFO','Storage: Cloudflare R2',NULL,NULL,'2026-04-07 14:41:04'),('01KNM67K8TQJMDP7XQZ4FYQQTF','WARN','GOOGLE_SERVICE_ACCOUNT_JSON not set — Google Drive integration disabled',NULL,NULL,'2026-04-07 14:41:04'),('01KNM67K93WBQGW0H5PW4S92G8','INFO','API server running on port 4000',NULL,NULL,'2026-04-07 14:41:04'),('01KNM67KJET6GYFTMG827YZTKQ','INFO','Socket.io server running on port 4001',NULL,NULL,'2026-04-07 14:41:05'),('01KNM67KYMPJ2J1W5Z1ZJRZB5K','INFO','Restart notification email sent to admin',NULL,NULL,'2026-04-07 14:41:05'),('01KNM6DE7JAC1JQ94ATKACV9F0','FATAL','Uncaught exception: Socket closed unexpectedly','{\"errorName\":\"SocketClosedUnexpectedlyError\"}','Error: Socket closed unexpectedly\n    at Socket.<anonymous> (/app/node_modules/@redis/client/dist/lib/client/socket.js:232:33)\n    at Object.onceWrapper (node:events:639:26)\n    at Socket.emit (node:events:524:28)\n    at TCP.<anonymous> (node:net:343:12)','2026-04-07 14:44:16'),('01KNM6DE7X7PKR1V6M9R67YHSC','FATAL','Uncaught exception: Socket closed unexpectedly','{\"errorName\":\"SocketClosedUnexpectedlyError\"}','Error: Socket closed unexpectedly\n    at Socket.<anonymous> (/app/node_modules/@redis/client/dist/lib/client/socket.js:232:33)\n    at Object.onceWrapper (node:events:639:26)\n    at Socket.emit (node:events:524:28)\n    at TCP.<anonymous> (node:net:343:12)','2026-04-07 14:44:16'),('01KNM6DJ1WRRP2VM0TX1JQVJP8','INFO','[Worker] Connecting to Redis...','{\"source\":\"worker\"}',NULL,'2026-04-07 14:44:20'),('01KNM6DJ440B19AVAMV0SNEKGT','INFO','[Worker] Starting workers...','{\"source\":\"worker\"}',NULL,'2026-04-07 14:44:20'),('01KNM6DJ63GS6RW9CGYYDVWN7B','INFO','[Worker] All workers started: image-process(3), image-expiry, storage-monitor, email-send(5), drive-import(2)','{\"source\":\"worker\"}',NULL,'2026-04-07 14:44:20'),('01KNM6DKFFN1KZT7J4GAB07BN5','INFO','Storage: Cloudflare R2',NULL,NULL,'2026-04-07 14:44:21'),('01KNM6DKHQC9VSDVE4BP35KPMY','WARN','GOOGLE_SERVICE_ACCOUNT_JSON not set — Google Drive integration disabled',NULL,NULL,'2026-04-07 14:44:21'),('01KNM6DKHY01GKKMQ6DN0BTJX9','INFO','API server running on port 4000',NULL,NULL,'2026-04-07 14:44:21'),('01KNM6DKTXS5NC70NXXGX7ZSMS','INFO','Socket.io server running on port 4001',NULL,NULL,'2026-04-07 14:44:21'),('01KNM6DM2VE44YFZ1B9RX1NBDP','INFO','Restart notification email sent to admin',NULL,NULL,'2026-04-07 14:44:22'),('01KNM7QFK2XM6TRAA5Z3GWYFP2','INFO','GET /api/health 200 (14ms)','{\"requestId\":\"01KNM7QFJJS95PQ97ABXF5TBBG\",\"method\":\"GET\",\"url\":\"/api/health\",\"statusCode\":200,\"durationMs\":14}',NULL,'2026-04-07 15:07:13'),('01KNM81GBGNXJT9ADYH95BGZT7','INFO','GET /api/health 200 (2ms)','{\"requestId\":\"01KNM81GBD0GMCH43R4VEPJ1T7\",\"method\":\"GET\",\"url\":\"/api/health\",\"statusCode\":200,\"durationMs\":2}',NULL,'2026-04-07 15:12:42'),('01KNM8AVM3CVMMPTYMZCZCTQFF','INFO','GET /api/health 200 (3ms)','{\"requestId\":\"01KNM8AVKZW5PC4JDHZY8TSBEW\",\"method\":\"GET\",\"url\":\"/api/health\",\"statusCode\":200,\"durationMs\":3}',NULL,'2026-04-07 15:17:48'),('01KNM8EMAWRKR0K7RN0012Z3GR','INFO','Storage: Cloudflare R2',NULL,NULL,'2026-04-07 15:19:52'),('01KNM8EMBPT2QS97QM5NNGZZ8V','WARN','GOOGLE_SERVICE_ACCOUNT_JSON not set — Google Drive integration disabled',NULL,NULL,'2026-04-07 15:19:52'),('01KNM8EMBXMSPFJBYN3DDGWZV3','INFO','API server running on port 4000',NULL,NULL,'2026-04-07 15:19:52'),('01KNM8EMQC5CWCF0Z54N140SFV','INFO','Socket.io server running on port 4001',NULL,NULL,'2026-04-07 15:19:52'),('01KNM8EN1AV7XTWF5GY04GN8VK','INFO','Restart notification email sent to admin',NULL,NULL,'2026-04-07 15:19:53'),('01KNMANWJ2BM8Z63T3MD448GGX','INFO','GET /api/health 200 (17ms)','{\"requestId\":\"01KNMANWHG62NH7QX65XS9ENFE\",\"method\":\"GET\",\"url\":\"/api/health\",\"statusCode\":200,\"durationMs\":17}',NULL,'2026-04-07 15:58:47'),('01KNMBDZPJDJTYKWKDZ4G2JEAV','INFO','GET /api/health 200 (2ms)','{\"requestId\":\"01KNMBDZPGZYXMDCK7QD94TQHW\",\"method\":\"GET\",\"url\":\"/api/health\",\"statusCode\":200,\"durationMs\":2}',NULL,'2026-04-07 16:11:56'),('01KNMBH4ZZ99G0RW8AGZQCZ3AV','WARN','POST /api/graphql 404 (7ms)','{\"requestId\":\"01KNMBH4ZQ6D5B0WRZMPR9SQ15\",\"method\":\"POST\",\"url\":\"/api/graphql\",\"statusCode\":404,\"durationMs\":7,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot POST /api/graphql</pre>\\n</body>\\n</html>\\n\",\"ip\":\"::ffff:172.20.0.3\",\"ua\":\"Mozilla/5.0 (l9scan/2.0.732313e2731323e2839313e2334313; +https://leakix.net)\"}',NULL,'2026-04-07 16:13:40'),('01KNMBH56CW7JJPBABA9BWKTRM','WARN','POST /api/graphql 404 (3ms)','{\"requestId\":\"01KNMBH568P97G9EQXS14HYW3D\",\"method\":\"POST\",\"url\":\"/api/graphql\",\"statusCode\":404,\"durationMs\":3,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot POST /api/graphql</pre>\\n</body>\\n</html>\\n\",\"ip\":\"::ffff:172.20.0.3\",\"ua\":\"Mozilla/5.0 (l9scan/2.0.732313e2731323e2839313e2334313; +https://leakix.net)\"}',NULL,'2026-04-07 16:13:40'),('01KNMBH5M6VA7CDP2MSS3X3BGD','WARN','POST /api/gql 404 (6ms)','{\"requestId\":\"01KNMBH5KYHKQXCM8CASCEEJYG\",\"method\":\"POST\",\"url\":\"/api/gql\",\"statusCode\":404,\"durationMs\":6,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot POST /api/gql</pre>\\n</body>\\n</html>\\n\",\"ip\":\"::ffff:172.20.0.3\",\"ua\":\"Mozilla/5.0 (l9scan/2.0.732313e2731323e2839313e2334313; +https://leakix.net)\"}',NULL,'2026-04-07 16:13:41'),('01KNMBH5WGBFXP1TE8S83FMJKD','WARN','POST /api/gql 404 (1ms)','{\"requestId\":\"01KNMBH5WDXD9F0KBN9CSD4JYJ\",\"method\":\"POST\",\"url\":\"/api/gql\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot POST /api/gql</pre>\\n</body>\\n</html>\\n\",\"ip\":\"::ffff:172.20.0.3\",\"ua\":\"Mozilla/5.0 (l9scan/2.0.732313e2731323e2839313e2334313; +https://leakix.net)\"}',NULL,'2026-04-07 16:13:41'),('01KNMBH64JKZ3C16CF0GX269Z1','WARN','POST /api/graphql 404 (4ms)','{\"requestId\":\"01KNMBH64EJHHRPHVMNCJ28PYR\",\"method\":\"POST\",\"url\":\"/api/graphql\",\"statusCode\":404,\"durationMs\":4,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot POST /api/graphql</pre>\\n</body>\\n</html>\\n\",\"ip\":\"::ffff:172.20.0.3\",\"ua\":\"Mozilla/5.0 (l9scan/2.0.732313e2731323e2839313e2334313; +https://leakix.net)\"}',NULL,'2026-04-07 16:13:41'),('01KNMBH761FPPK960555W9ZVMK','WARN','POST /api/gql 404 (2ms)','{\"requestId\":\"01KNMBH75Y2M9CVBBTZEDRSM4A\",\"method\":\"POST\",\"url\":\"/api/gql\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot POST /api/gql</pre>\\n</body>\\n</html>\\n\",\"ip\":\"::ffff:172.20.0.3\",\"ua\":\"Mozilla/5.0 (l9scan/2.0.732313e2731323e2839313e2334313; +https://leakix.net)\"}',NULL,'2026-04-07 16:13:42'),('01KNMBHJ41TG4B66GJD75DVXHR','WARN','POST /api/graphql 404 (2ms)','{\"requestId\":\"01KNMBHJ3ZSNEZN0ZP3F6RJQR8\",\"method\":\"POST\",\"url\":\"/api/graphql\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot POST /api/graphql</pre>\\n</body>\\n</html>\\n\",\"ip\":\"::ffff:172.20.0.3\",\"ua\":\"Mozilla/5.0 (l9scan/2.0.732313e2731323e2839313e2334313; +https://leakix.net)\"}',NULL,'2026-04-07 16:13:54'),('01KNMBHJTZVQPKJMB8HW183VV3','WARN','POST /api/gql 404 (2ms)','{\"requestId\":\"01KNMBHJTW9TD6J187VFMXA7N9\",\"method\":\"POST\",\"url\":\"/api/gql\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot POST /api/gql</pre>\\n</body>\\n</html>\\n\",\"ip\":\"::ffff:172.20.0.3\",\"ua\":\"Mozilla/5.0 (l9scan/2.0.732313e2731323e2839313e2334313; +https://leakix.net)\"}',NULL,'2026-04-07 16:13:54'),('01KNMBHNJKDX05BWB9TXP02716','WARN','GET /api/swagger.json 404 (7ms)','{\"requestId\":\"01KNMBHNJCZDN2QNAVWF4SMSXY\",\"method\":\"GET\",\"url\":\"/api/swagger.json\",\"statusCode\":404,\"durationMs\":7,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /api/swagger.json</pre>\\n</body>\\n</html>\\n\",\"ip\":\"::ffff:172.20.0.3\",\"ua\":\"Mozilla/5.0 (l9scan/2.0.732313e2731323e2839313e2334313; +https://leakix.net)\"}',NULL,'2026-04-07 16:13:57'),('01KNMBHNVZRKGS73WYWPANDMR5','WARN','GET /api/swagger.json 404 (2ms)','{\"requestId\":\"01KNMBHNVWDVTJYEN62N6MYQYV\",\"method\":\"GET\",\"url\":\"/api/swagger.json\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /api/swagger.json</pre>\\n</body>\\n</html>\\n\",\"ip\":\"::ffff:172.20.0.3\",\"ua\":\"Mozilla/5.0 (l9scan/2.0.732313e2731323e2839313e2334313; +https://leakix.net)\"}',NULL,'2026-04-07 16:13:58'),('01KNMBHQCAAPYSKR65HJMH79M5','WARN','GET /api/swagger.json 404 (2ms)','{\"requestId\":\"01KNMBHQC8AWJXB40SWF2A6KBK\",\"method\":\"GET\",\"url\":\"/api/swagger.json\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /api/swagger.json</pre>\\n</body>\\n</html>\\n\",\"ip\":\"::ffff:172.20.0.3\",\"ua\":\"Mozilla/5.0 (l9scan/2.0.732313e2731323e2839313e2334313; +https://leakix.net)\"}',NULL,'2026-04-07 16:13:59'),('01KNMBJ2VS85F9RAX6ZY9FW76E','WARN','GET /api/swagger.json 404 (2ms)','{\"requestId\":\"01KNMBJ2VP5FD3KZJAMYWGJD33\",\"method\":\"GET\",\"url\":\"/api/swagger.json\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /api/swagger.json</pre>\\n</body>\\n</html>\\n\",\"ip\":\"::ffff:172.20.0.3\",\"ua\":\"Mozilla/5.0 (l9scan/2.0.732313e2731323e2839313e2334313; +https://leakix.net)\"}',NULL,'2026-04-07 16:14:11'),('01KNMBJP56XCR8HQ93XZCPTTQN','INFO','Storage: Cloudflare R2',NULL,NULL,'2026-04-07 16:14:31'),('01KNMBJP6DXQXGM6Z1001G43CG','WARN','GOOGLE_SERVICE_ACCOUNT_JSON not set — Google Drive integration disabled',NULL,NULL,'2026-04-07 16:14:31'),('01KNMBJP6MAS3TXQYM18ZNSWV9','INFO','API server running on port 4000',NULL,NULL,'2026-04-07 16:14:31'),('01KNMBJPH6ZQ9QZEYR1HV59D1S','INFO','Socket.io server running on port 4001',NULL,NULL,'2026-04-07 16:14:31'),('01KNMBJPTMZV0YSY54AEDD2HHM','INFO','Restart notification email sent to admin',NULL,NULL,'2026-04-07 16:14:31'),('01KNMBVZ7XQBBWQEKEFHSC7ZJB','INFO','GET /api/health 200 (7ms)','{\"requestId\":\"01KNMBVZ7NF04VC22Q8600WNMD\",\"method\":\"GET\",\"url\":\"/api/health\",\"statusCode\":200,\"durationMs\":7}',NULL,'2026-04-07 16:19:35'),('01KNMC0CCJVTEK7P2CSZRYNP3Y','WARN','GOOGLE_SERVICE_ACCOUNT_JSON not set — Google Drive integration disabled',NULL,NULL,'2026-04-07 16:21:59'),('01KNMC0CCTSZ3YP5TZ7TJZVAJR','INFO','API server running on port 4000',NULL,NULL,'2026-04-07 16:21:59'),('01KNMC0CK9CJXS5W152VHF01RA','INFO','Socket.io server running on port 4001',NULL,NULL,'2026-04-07 16:22:00'),('01KNMC0D2RV5W63SNZ0AKDXDF1','INFO','Restart notification email sent to admin',NULL,NULL,'2026-04-07 16:22:00'),('01KNMC9CPBS4PVXT6XHR48772W','INFO','GET /api/health 200 (6ms)','{\"requestId\":\"01KNMC9CP4K4JB5J4981NVMPVS\",\"method\":\"GET\",\"url\":\"/api/health\",\"statusCode\":200,\"durationMs\":6}',NULL,'2026-04-07 16:26:55'),('01KNMD38Y8F83SVZC19VR6K55T','INFO','Socket.io server running on port 4001',NULL,NULL,'2026-04-07 16:41:03'),('01KNMDBGWP06200JW57B1M1Y3K','INFO','GET /api/health 200 (7ms)','{\"requestId\":\"01KNMDBGWEJW24FKF134EF7FVN\",\"method\":\"GET\",\"url\":\"/api/health\",\"statusCode\":200,\"durationMs\":7}',NULL,'2026-04-07 16:45:33'),('01KNMDW3WTZ0K6D12BAAPRMRQH','WARN','POST /api/auth/refresh 401 (3ms)','{\"requestId\":\"01KNMDW3WQS5K5Q883RSTHY24X\",\"method\":\"POST\",\"url\":\"/api/auth/refresh\",\"statusCode\":401,\"durationMs\":3,\"resBody\":\"{\\\"message\\\":\\\"Không có refresh token\\\"}\",\"ip\":\"27.76.182.160\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 16:54:37'),('01KNMDW49Z742Y1XMBN742QX6D','INFO','GET /api/albums?limit=12 200 (24ms)','{\"requestId\":\"01KNMDW497QH75RR1MCPZE8TYK\",\"method\":\"GET\",\"url\":\"/api/albums?limit=12\",\"statusCode\":200,\"durationMs\":24}',NULL,'2026-04-07 16:54:37'),('01KNMDWY3GVBTMMCEMDX5M24HH','INFO','GET /api/health 200 (2ms)','{\"requestId\":\"01KNMDWY3EJFY1EWS5ZXW3XRYK\",\"method\":\"GET\",\"url\":\"/api/health\",\"statusCode\":200,\"durationMs\":2}',NULL,'2026-04-07 16:55:04'),('01KNMDXJ82QEDT6HWHXTFVG9Z4','WARN','POST /api/auth/refresh 401 (1ms)','{\"requestId\":\"01KNMDXJ7ZQRT1VDGTBK7WMBE3\",\"method\":\"POST\",\"url\":\"/api/auth/refresh\",\"statusCode\":401,\"durationMs\":1,\"resBody\":\"{\\\"message\\\":\\\"Không có refresh token\\\"}\",\"ip\":\"27.76.182.160\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 16:55:24'),('01KNMDXJAKSE8667P2K5H6DDKK','INFO','GET /api/albums?limit=12 304 (3ms)','{\"requestId\":\"01KNMDXJAG5CMVE9M9XD3NFEJ2\",\"method\":\"GET\",\"url\":\"/api/albums?limit=12\",\"statusCode\":304,\"durationMs\":3}',NULL,'2026-04-07 16:55:24'),('01KNMDXKF1FXFNEW4QYMY746SW','WARN','POST /api/auth/refresh 401 (1ms)','{\"requestId\":\"01KNMDXKEZ965GDY4H3J8CXE10\",\"method\":\"POST\",\"url\":\"/api/auth/refresh\",\"statusCode\":401,\"durationMs\":1,\"resBody\":\"{\\\"message\\\":\\\"Không có refresh token\\\"}\",\"ip\":\"27.76.182.160\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 16:55:25'),('01KNMDXKHHWZG1TD1VV3PARQ98','INFO','GET /api/albums?limit=12 304 (4ms)','{\"requestId\":\"01KNMDXKHC50DSBNDFM31AWMS5\",\"method\":\"GET\",\"url\":\"/api/albums?limit=12\",\"statusCode\":304,\"durationMs\":4}',NULL,'2026-04-07 16:55:25'),('01KNMDY9CZY8DHWQ52ZCE30T8M','WARN','POST /api/auth/refresh 401 (1ms)','{\"requestId\":\"01KNMDY9CX676FFYHVB12DEPRV\",\"method\":\"POST\",\"url\":\"/api/auth/refresh\",\"statusCode\":401,\"durationMs\":1,\"resBody\":\"{\\\"message\\\":\\\"Không có refresh token\\\"}\",\"ip\":\"27.76.182.160\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 16:55:48'),('01KNMDY9HHWMFQFKFWNPXMCV77','INFO','GET /api/albums?limit=12 200 (3ms)','{\"requestId\":\"01KNMDY9HEYBB12MBTBZK7HT67\",\"method\":\"GET\",\"url\":\"/api/albums?limit=12\",\"statusCode\":200,\"durationMs\":3}',NULL,'2026-04-07 16:55:48'),('01KNME1CHPM9GS5JN337BQD2EC','WARN','POST /api/auth/refresh 401 (2ms)','{\"requestId\":\"01KNME1CHJXZYFF2RYZZ1J5E06\",\"method\":\"POST\",\"url\":\"/api/auth/refresh\",\"statusCode\":401,\"durationMs\":2,\"resBody\":\"{\\\"message\\\":\\\"Không có refresh token\\\"}\",\"ip\":\"27.76.182.160\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 16:57:29'),('01KNME1CQ8R6VH1CY529WHWMBM','INFO','GET /api/albums?limit=12 200 (3ms)','{\"requestId\":\"01KNME1CQ5875FQPTZJWZXZ3DA\",\"method\":\"GET\",\"url\":\"/api/albums?limit=12\",\"statusCode\":200,\"durationMs\":3}',NULL,'2026-04-07 16:57:30'),('01KNME1V57XVJD7TMYDMDTMEX3','WARN','POST /api/auth/refresh 401 (2ms)','{\"requestId\":\"01KNME1V55SDT929N8Z3Q30ZSM\",\"method\":\"POST\",\"url\":\"/api/auth/refresh\",\"statusCode\":401,\"durationMs\":2,\"resBody\":\"{\\\"message\\\":\\\"Không có refresh token\\\"}\",\"ip\":\"27.76.182.160\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 16:57:44'),('01KNME1V7AEDGPJ7GDEN88D58C','INFO','GET /api/albums?limit=12 304 (2ms)','{\"requestId\":\"01KNME1V7750MYXAP8V1CX2FGK\",\"method\":\"GET\",\"url\":\"/api/albums?limit=12\",\"statusCode\":304,\"durationMs\":2}',NULL,'2026-04-07 16:57:44'),('01KNME20918W33787H1TT82N5Q','INFO','GET /api/health 200 (2ms)','{\"requestId\":\"01KNME208Z1K9Z3HA7FNPPQP9K\",\"method\":\"GET\",\"url\":\"/api/health\",\"statusCode\":200,\"durationMs\":2}',NULL,'2026-04-07 16:57:50'),('01KNME5XGPCWW3KAAEZKWE4184','WARN','GET /.git/config 404 (4ms)','{\"requestId\":\"01KNME5XGJGR2HN9WMZC415MNE\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":4,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"210.79.190.121\",\"ua\":\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15\"}',NULL,'2026-04-07 16:59:58'),('01KNME7DTQD3NDT4CV8BWNC3QA','WARN','POST /api/auth/refresh 401 (23ms)','{\"requestId\":\"01KNME7DT0G7BGCNEQZR7GAXNW\",\"method\":\"POST\",\"url\":\"/api/auth/refresh\",\"statusCode\":401,\"durationMs\":23,\"resBody\":\"{\\\"message\\\":\\\"Refresh token không hợp lệ\\\"}\",\"ip\":\"27.76.182.160\",\"ua\":\"Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/146.0.7680.151 Mobile/15E148 Safari/604.1\"}',NULL,'2026-04-07 17:00:47'),('01KNME7DZE8GKNSM7V3SHHAV8F','WARN','Chưa đăng nhập','{\"requestId\":\"01KNME7DZAAZAJKVESR076Q6MY\",\"method\":\"GET\",\"url\":\"/api/users/me/albums\",\"statusCode\":401,\"stackOrigin\":\"Error: Chưa đăng nhập\\n    at requireAuth (file:///app/dist/middleware/auth.js:21:21)\\n    at file:///app/dist/routes/users/me.js:105:18\\n    at Layer.handleRequest (/app/node_modules/router/lib/layer.js:152:17)\"}',NULL,'2026-04-07 17:00:47'),('01KNME7DZGNJRW2XBVBWDJ5437','WARN','GET /api/users/me/albums 401 (6ms)','{\"requestId\":\"01KNME7DZAAZAJKVESR076Q6MY\",\"method\":\"GET\",\"url\":\"/api/users/me/albums\",\"statusCode\":401,\"durationMs\":6,\"resBody\":\"{\\\"message\\\":\\\"Chưa đăng nhập\\\",\\\"requestId\\\":\\\"01KNME7DZAAZAJKVESR076Q6MY\\\"}\",\"ip\":\"27.76.182.160\",\"ua\":\"Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/146.0.7680.151 Mobile/15E148 Safari/604.1\"}',NULL,'2026-04-07 17:00:47'),('01KNME7E1MWQGDC03E4FHMXPFF','WARN','POST /api/auth/refresh 401 (8ms)','{\"requestId\":\"01KNME7E1CEGP8H8624Z12CP0S\",\"method\":\"POST\",\"url\":\"/api/auth/refresh\",\"statusCode\":401,\"durationMs\":8,\"resBody\":\"{\\\"message\\\":\\\"Refresh token không hợp lệ\\\"}\",\"ip\":\"27.76.182.160\",\"ua\":\"Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/146.0.7680.151 Mobile/15E148 Safari/604.1\"}',NULL,'2026-04-07 17:00:48'),('01KNME7E3T81103YAQ469M2KBK','WARN','Chưa đăng nhập','{\"requestId\":\"01KNME7E3RK53Q5T37TYMBJ5YR\",\"method\":\"POST\",\"url\":\"/api/auth/logout\",\"statusCode\":401,\"stackOrigin\":\"Error: Chưa đăng nhập\\n    at requireAuth (file:///app/dist/middleware/auth.js:21:21)\\n    at file:///app/dist/routes/auth/logout.js:8:18\\n    at Layer.handleRequest (/app/node_modules/router/lib/layer.js:152:17)\"}',NULL,'2026-04-07 17:00:48'),('01KNME7E3WAYVDNYCQEQTEN1TA','WARN','POST /api/auth/logout 401 (4ms)','{\"requestId\":\"01KNME7E3RK53Q5T37TYMBJ5YR\",\"method\":\"POST\",\"url\":\"/api/auth/logout\",\"statusCode\":401,\"durationMs\":4,\"resBody\":\"{\\\"message\\\":\\\"Chưa đăng nhập\\\",\\\"requestId\\\":\\\"01KNME7E3RK53Q5T37TYMBJ5YR\\\"}\",\"ip\":\"27.76.182.160\",\"ua\":\"Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/146.0.7680.151 Mobile/15E148 Safari/604.1\"}',NULL,'2026-04-07 17:00:48'),('01KNME7JBK6GPAETAMP5SXWZ39','WARN','POST /api/auth/refresh 401 (4ms)','{\"requestId\":\"01KNME7JBFSQ6XKB44GC6QB0CJ\",\"method\":\"POST\",\"url\":\"/api/auth/refresh\",\"statusCode\":401,\"durationMs\":4,\"resBody\":\"{\\\"message\\\":\\\"Refresh token không hợp lệ\\\"}\",\"ip\":\"27.76.182.160\",\"ua\":\"Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/146.0.7680.151 Mobile/15E148 Safari/604.1\"}',NULL,'2026-04-07 17:00:52'),('01KNME7TR4E0FBRHYQF5F42D9W','WARN','POST /api/auth/refresh 401 (4ms)','{\"requestId\":\"01KNME7TR0H6VKPBBQJ9F5C3N3\",\"method\":\"POST\",\"url\":\"/api/auth/refresh\",\"statusCode\":401,\"durationMs\":4,\"resBody\":\"{\\\"message\\\":\\\"Refresh token không hợp lệ\\\"}\",\"ip\":\"27.76.182.160\",\"ua\":\"Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/146.0.7680.151 Mobile/15E148 Safari/604.1\"}',NULL,'2026-04-07 17:01:01'),('01KNME7TWWQRQ1FFZXYNXRWD5Y','INFO','GET /api/albums?limit=12 200 (14ms)','{\"requestId\":\"01KNME7TWD91KZDKD0VH78N7G9\",\"method\":\"GET\",\"url\":\"/api/albums?limit=12\",\"statusCode\":200,\"durationMs\":14}',NULL,'2026-04-07 17:01:01'),('01KNMEEWC7FJCH4MRX67FDJZ0K','INFO','GET /api/cron/remind-payments 200 (13ms)','{\"requestId\":\"01KNMEEWBSAFPDYA89HDJXSQHA\",\"method\":\"GET\",\"url\":\"/api/cron/remind-payments\",\"statusCode\":200,\"durationMs\":13}',NULL,'2026-04-07 17:04:52'),('01KNMF3ZP5514JKGBN59GJME5X','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMF3ZP3BSTDWKPBTEGP7W6G\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"104.252.191.103\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 17:16:23'),('01KNMF47M8DZ43Z7J65AHTC8AQ','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMF47M7BR1SMEQ73PJW33YT\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"103.4.251.27\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 17:16:31'),('01KNMFJT4NHFFMM7WF8XY3SP0T','WARN','GET / 404 (2ms)','{\"requestId\":\"01KNMFJT4KAV3Z2WNBE4WZ5508\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"91.196.152.68\",\"ua\":\"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0\"}',NULL,'2026-04-07 17:24:29'),('01KNMFQWE9J6SA5G1F7WJXMXCM','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMFQWE7P0SXB8HQW93WHNRT\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"104.252.191.120\",\"ua\":\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 17:27:15'),('01KNMFR9P55DRWNCDZPMH4M5F6','WARN','GET / 404 (2ms)','{\"requestId\":\"01KNMFR9P2V02FV53P4PH1N41Z\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"107.172.195.97\",\"ua\":\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 17:27:29'),('01KNMFT76AHBATX2ATSX4SDF02','WARN','GET /.git/config 404 (12ms)','{\"requestId\":\"01KNMFT75Y19MXW9MG5SH2ST23\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":12,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"40.76.238.177\",\"ua\":\"Mozilla/5.0 (iPhone; CPU iPhone OS 16_7_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.7 Mobile/15E148 Safari/604.1\"}',NULL,'2026-04-07 17:28:32'),('01KNMFV9NE4ZBCJ66GGBG0S5Q0','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMFV9NDHCW6ZNRVGMK3518Y\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"145.132.100.73\",\"ua\":\"Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36\"}',NULL,'2026-04-07 17:29:07'),('01KNMFWBTVFXPF20NSW0GX599C','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMFWBTR5MCPMZPNA60E4X4H\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"172.202.102.216\",\"ua\":\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 17:29:42'),('01KNMG6FDSKR30SFQJ6SBKZGZ6','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMG6FDQEWY9DT9MPCC50RFB\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 YaBrowser/21.8.1.468 Yowser/2.5 Safari/537.36\"}',NULL,'2026-04-07 17:35:13'),('01KNMG6FX9G7CWRMR1SRXHDP87','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMG6FX8XNR0KQVX0YVK9M9Z\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36\"}',NULL,'2026-04-07 17:35:14'),('01KNMG6H6CCAD46BP3N6KXPA28','WARN','GET /favicon.ico 404 (1ms)','{\"requestId\":\"01KNMG6H6AFXWWSQM7AHVCPEKQ\",\"method\":\"GET\",\"url\":\"/favicon.ico\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /favicon.ico</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36\"}',NULL,'2026-04-07 17:35:15'),('01KNMG6JT485VMPPWM5AQ4A0QP','WARN','GET /favicon.ico 404 (1ms)','{\"requestId\":\"01KNMG6JT2CTK99KJYBF0G3AXY\",\"method\":\"GET\",\"url\":\"/favicon.ico\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /favicon.ico</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 YaBrowser/21.8.1.468 Yowser/2.5 Safari/537.36\"}',NULL,'2026-04-07 17:35:17'),('01KNMG6Q66A9CQW6PM218QJ4DJ','WARN','GET /.well-known/security.txt 404 (2ms)','{\"requestId\":\"01KNMG6Q64D56JYYVMVHM4S6WF\",\"method\":\"GET\",\"url\":\"/.well-known/security.txt\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.well-known/security.txt</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36\"}',NULL,'2026-04-07 17:35:21'),('01KNMG6RQ4J68JTHJ8KZ85TEC3','WARN','GET /favicon.ico 404 (2ms)','{\"requestId\":\"01KNMG6RQ2C5NDPH629BG621BW\",\"method\":\"GET\",\"url\":\"/favicon.ico\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /favicon.ico</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36\"}',NULL,'2026-04-07 17:35:23'),('01KNMG6WYQ0W6D8JZH78MRST7A','WARN','GET /.well-known/security.txt 404 (1ms)','{\"requestId\":\"01KNMG6WYN3143KBGH6MAXTHAV\",\"method\":\"GET\",\"url\":\"/.well-known/security.txt\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.well-known/security.txt</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 YaBrowser/21.8.1.468 Yowser/2.5 Safari/537.36\"}',NULL,'2026-04-07 17:35:27'),('01KNMG6X106RA9Q65T3EWGY7FP','WARN','GET /security.txt 404 (3ms)','{\"requestId\":\"01KNMG6X0WT17MEMPTC7NGKP0P\",\"method\":\"GET\",\"url\":\"/security.txt\",\"statusCode\":404,\"durationMs\":3,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /security.txt</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36\"}',NULL,'2026-04-07 17:35:27'),('01KNMG6YGJYP5D94D68P0JS315','WARN','GET /favicon.ico 404 (2ms)','{\"requestId\":\"01KNMG6YGGJ6YJX7ZSFJHCP2FV\",\"method\":\"GET\",\"url\":\"/favicon.ico\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /favicon.ico</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 YaBrowser/21.8.1.468 Yowser/2.5 Safari/537.36\"}',NULL,'2026-04-07 17:35:29'),('01KNMG6YHDQ17SW2N5W8JFR0EW','WARN','GET /favicon.ico 404 (17ms)','{\"requestId\":\"01KNMG6YGWAZD4MYCPX27YJ5ZS\",\"method\":\"GET\",\"url\":\"/favicon.ico\",\"statusCode\":404,\"durationMs\":17,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /favicon.ico</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36\"}',NULL,'2026-04-07 17:35:29'),('01KNMG72E61BA1BGHVPRW98335','WARN','GET /security.txt 404 (2ms)','{\"requestId\":\"01KNMG72E45J3HMMR6B90N04BS\",\"method\":\"GET\",\"url\":\"/security.txt\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /security.txt</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 YaBrowser/21.8.1.468 Yowser/2.5 Safari/537.36\"}',NULL,'2026-04-07 17:35:33'),('01KNMG740FHXECVMBVASYVQTJV','WARN','GET /favicon.ico 404 (1ms)','{\"requestId\":\"01KNMG740EPPV9ZA7V7R0CSF0D\",\"method\":\"GET\",\"url\":\"/favicon.ico\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /favicon.ico</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 YaBrowser/21.8.1.468 Yowser/2.5 Safari/537.36\"}',NULL,'2026-04-07 17:35:34'),('01KNMGAZVZVWC586ACHJD3K05W','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMGAZVXM5J5GA40T123E9Q9\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.86 YaBrowser/21.3.1.186 Yowser/2.5 Safari/537.36\"}',NULL,'2026-04-07 17:37:41'),('01KNMGB0XD8ATSA4RRK30Q0WWZ','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMGB0XCFE05A6A20S8E1T7F\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36\"}',NULL,'2026-04-07 17:37:42'),('01KNMGB1KJEK4Z5XN6ZGZC5BBW','WARN','GET /favicon.ico 404 (1ms)','{\"requestId\":\"01KNMGB1KGNH3X5F9JNB3WRA7K\",\"method\":\"GET\",\"url\":\"/favicon.ico\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /favicon.ico</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.86 YaBrowser/21.3.1.186 Yowser/2.5 Safari/537.36\"}',NULL,'2026-04-07 17:37:43'),('01KNMGB284ER3TYN0H53B8BS1J','WARN','GET /favicon.ico 404 (1ms)','{\"requestId\":\"01KNMGB283WM7WHJ3TE31CY9P0\",\"method\":\"GET\",\"url\":\"/favicon.ico\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /favicon.ico</pre>\\n</body>\\n</html>\\n\",\"ip\":\"81.29.142.100\",\"ua\":\"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36\"}',NULL,'2026-04-07 17:37:44'),('01KNMGEZ8V02DB1D0YSRQFCSRZ','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMGEZ8SRHYNTPPFAWGW4ER0\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"103.196.9.157\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 17:39:52'),('01KNMGTHNAFXYWK4NV41PV3MDJ','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMGTHN931AVZEHJ1FAN6K04\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"172.182.203.52\",\"ua\":\"Mozilla/5.0 (X11; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0\"}',NULL,'2026-04-07 17:46:11'),('01KNMGVAB0GEPH4ESW8M9HB5HA','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMGVAAZYSKMV88Y066849NK\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"64.236.133.179\",\"ua\":\"Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36\"}',NULL,'2026-04-07 17:46:36'),('01KNMGX0VMHRWCVGADKKF978MC','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMGX0VJ9GGG7K20M06VRRSV\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"52.190.141.40\",\"ua\":\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:134.0) Gecko/20100101 Firefox/134.0\"}',NULL,'2026-04-07 17:47:32'),('01KNMH17XVRAX7684ZBJ2JK9GM','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMH17XT0X183DVRK5XK7CR5\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"64.236.141.182\",\"ua\":\"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0\"}',NULL,'2026-04-07 17:49:50'),('01KNMH32VRC1XWZCMPPCTWJ0NX','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMH32VQCJGXFSH8NQ0TCDX2\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"172.212.171.146\",\"ua\":\"Mozilla/5.0 (Linux; Android 13; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36\"}',NULL,'2026-04-07 17:50:51'),('01KNMH3G29JNYF5ZXVDPBK3BC7','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMH3G27Y4FYQETVDG3Q7JD6\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"20.119.41.201\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0\"}',NULL,'2026-04-07 17:51:04'),('01KNMH805M3Q9QN8T2EPT9Y18Q','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMH805J7S5G22XHSHXJB89C\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"68.154.115.180\",\"ua\":\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15\"}',NULL,'2026-04-07 17:53:32'),('01KNMH957JJFQT74JAE5QDA51R','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMH957G65CNH3DNFNN80HTT\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"52.173.163.36\",\"ua\":\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 17:54:10'),('01KNMH9CQXSW1Z1ZGTB2TRPJ7F','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMH9CQWG5X25BQ25TW8DGN3\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"172.184.220.209\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0\"}',NULL,'2026-04-07 17:54:17'),('01KNMHA9SR3CRD4HPKWX2RBYJH','WARN','GET /@fs/etc/passwd?raw?? 404 (1ms)','{\"requestId\":\"01KNMHA9SPND0R7R6CWK0V8TFP\",\"method\":\"GET\",\"url\":\"/@fs/etc/passwd?raw??\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /@fs/etc/passwd</pre>\\n</body>\\n</html>\\n\",\"ip\":\"172.182.212.5\",\"ua\":\"Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0\"}',NULL,'2026-04-07 17:54:47'),('01KNMHA9ZMDFDEX4G1RB60Y26V','WARN','GET /@fs/etc/passwd?import&raw?? 404 (1ms)','{\"requestId\":\"01KNMHA9ZKCPVZ8VBFTBCY4D6Z\",\"method\":\"GET\",\"url\":\"/@fs/etc/passwd?import&raw??\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /@fs/etc/passwd</pre>\\n</body>\\n</html>\\n\",\"ip\":\"172.182.212.5\",\"ua\":\"Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0\"}',NULL,'2026-04-07 17:54:47'),('01KNMHAA5GK9Q9FVBX4G7YSE6G','WARN','GET /etc/passwd?raw?? 404 (1ms)','{\"requestId\":\"01KNMHAA5EEJE3EGZPRV0JE2W1\",\"method\":\"GET\",\"url\":\"/etc/passwd?raw??\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /etc/passwd</pre>\\n</body>\\n</html>\\n\",\"ip\":\"172.182.212.5\",\"ua\":\"Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0\"}',NULL,'2026-04-07 17:54:48'),('01KNMHAABA1QYKMKTD9MYNRVR9','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMHAAB821FHK3R6WPSN29XK\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"172.182.212.5\",\"ua\":\"Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0\"}',NULL,'2026-04-07 17:54:48'),('01KNMHN390VVJRHZYEVYS4THJ5','WARN','GET /@fs/etc/passwd?raw?? 404 (1ms)','{\"requestId\":\"01KNMHN38YSYDKRYNDNFMRZKN0\",\"method\":\"GET\",\"url\":\"/@fs/etc/passwd?raw??\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /@fs/etc/passwd</pre>\\n</body>\\n</html>\\n\",\"ip\":\"135.232.232.53\",\"ua\":\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15\"}',NULL,'2026-04-07 18:00:41'),('01KNMHN3FS3HG0VGT1ZXF6FNES','WARN','GET /@fs/etc/passwd?import&raw?? 404 (1ms)','{\"requestId\":\"01KNMHN3FQFDTSQF97CQFZD62M\",\"method\":\"GET\",\"url\":\"/@fs/etc/passwd?import&raw??\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /@fs/etc/passwd</pre>\\n</body>\\n</html>\\n\",\"ip\":\"135.232.232.53\",\"ua\":\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15\"}',NULL,'2026-04-07 18:00:41'),('01KNMHN3PE1FE9TBKGN07NS7NB','WARN','GET /etc/passwd?raw?? 404 (1ms)','{\"requestId\":\"01KNMHN3PDKH3399ZNHX8QYTJE\",\"method\":\"GET\",\"url\":\"/etc/passwd?raw??\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /etc/passwd</pre>\\n</body>\\n</html>\\n\",\"ip\":\"135.232.232.53\",\"ua\":\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15\"}',NULL,'2026-04-07 18:00:41'),('01KNMHN3XMMF8CKQAT68S75TMT','WARN','GET /.git/config 404 (1ms)','{\"requestId\":\"01KNMHN3XJ4G19X6VGDP6SN673\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"135.232.232.53\",\"ua\":\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15\"}',NULL,'2026-04-07 18:00:42'),('01KNMJFRT6RKPH4WYWV3HSXH80','WARN','GET /api/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php 404 (2ms)','{\"requestId\":\"01KNMJFRT4Y21HFJSMJ07Y2MN9\",\"method\":\"GET\",\"url\":\"/api/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /api/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php</pre>\\n</body>\\n</html>\\n\",\"ip\":\"163.7.1.156\",\"ua\":\"libredtail-http\"}',NULL,'2026-04-07 18:15:15'),('01KNMJRM8P4CTFCNDMEKY6PWHX','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMJRM8K4WWS4HQ4HHQRTMEJ\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:05'),('01KNMJRMGW8SXFYGGKW83JKYKH','WARN','GET //wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRMGVJQ5846SQFJVS3HT0\",\"method\":\"GET\",\"url\":\"//wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:06'),('01KNMJRMS4X773KCJZAJ5FKGP1','WARN','GET //xmlrpc.php?rsd 404 (1ms)','{\"requestId\":\"01KNMJRMS2AH87881GQ5FB2ZDD\",\"method\":\"GET\",\"url\":\"//xmlrpc.php?rsd\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //xmlrpc.php</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:06'),('01KNMJRN18N20VNPXXEMP4AMA8','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMJRN173GVXT1FTXVAPN9MJ\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:06'),('01KNMJRN9JV4GCCYQW2BQDXQFT','WARN','GET //blog/wp-includes/wlwmanifest.xml 404 (6ms)','{\"requestId\":\"01KNMJRN9CNQMWK9MX8XS8PG9A\",\"method\":\"GET\",\"url\":\"//blog/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":6,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //blog/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:06'),('01KNMJRNHT43X4DVWZXKSWA3DH','WARN','GET //web/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRNHRA0TZAZX4H9W5G7ZJ\",\"method\":\"GET\",\"url\":\"//web/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //web/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:07'),('01KNMJRNSZWJKR3FAQ0H32WAA1','WARN','GET //wordpress/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRNSXQYB9QGXAX5ZM2SY5\",\"method\":\"GET\",\"url\":\"//wordpress/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //wordpress/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:07'),('01KNMJRP25W1ZSDTNG2K23BN2V','WARN','GET //website/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRP23WATY8NTWQ9ZT076V\",\"method\":\"GET\",\"url\":\"//website/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //website/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:07'),('01KNMJRPAASE8Y132QDBP4NYES','WARN','GET //wp/wp-includes/wlwmanifest.xml 404 (2ms)','{\"requestId\":\"01KNMJRPA8GV3HAQP4FY8JHX1F\",\"method\":\"GET\",\"url\":\"//wp/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //wp/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:07'),('01KNMJRPJFPTFQFE4J3CER33BR','WARN','GET //news/wp-includes/wlwmanifest.xml 404 (2ms)','{\"requestId\":\"01KNMJRPJDKCER8XCWAP5ETWZ0\",\"method\":\"GET\",\"url\":\"//news/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //news/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:08'),('01KNMJRPTN675MYKBG4K4PZ4ZW','WARN','GET //2018/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRPTKDDKWX3PF93ZPNKR6\",\"method\":\"GET\",\"url\":\"//2018/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //2018/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:08'),('01KNMJRQ2T4JTGW6RAZZ1FFHYN','WARN','GET //2019/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRQ2R5A3SQN0NVCFSJMNM\",\"method\":\"GET\",\"url\":\"//2019/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //2019/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:08'),('01KNMJRQAZDCYAG6A18R1XA2ES','WARN','GET //shop/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRQAXMAQ3RMNCQEBY2TP7\",\"method\":\"GET\",\"url\":\"//shop/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //shop/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:08'),('01KNMJRQK3JTTXNM6MPW4K00TK','WARN','GET //wp1/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRQK2BQN36AXQ3S9BPZGF\",\"method\":\"GET\",\"url\":\"//wp1/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //wp1/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:09'),('01KNMJRQV8ZZ25B8BHX933A4CG','WARN','GET //test/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRQV7FZMXW5XTVQ8HETT9\",\"method\":\"GET\",\"url\":\"//test/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //test/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:09'),('01KNMJRR3G1M08ZPM7VCJGA16R','WARN','GET //media/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRR3ERDH3YQ2AY2CCD79K\",\"method\":\"GET\",\"url\":\"//media/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //media/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:09'),('01KNMJRRBND3K2GADWCGD25YMD','WARN','GET //wp2/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRRBKAD21RYJKQ3REWPRA\",\"method\":\"GET\",\"url\":\"//wp2/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //wp2/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:09'),('01KNMJRRKS7GRWHBTJ6BZ55PT2','WARN','GET //site/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRRKRQ63NJZT8RZSRG67A\",\"method\":\"GET\",\"url\":\"//site/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //site/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:10'),('01KNMJRRVY1RPBQZ2KYZ4RWFH8','WARN','GET //cms/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRRVXY36BM4J7FTASK4HN\",\"method\":\"GET\",\"url\":\"//cms/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //cms/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:10'),('01KNMJRS420RM67YCJ3STVQ1RE','WARN','GET //sito/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMJRS41NHE6PGQ7S741A9EE\",\"method\":\"GET\",\"url\":\"//sito/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //sito/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:20:10'),('01KNMK0B3Q0RDEVMNDQGC10Z0F','WARN','GET /.git/config 404 (6ms)','{\"requestId\":\"01KNMK0B3HM0GH0BAGZ9ES6AHK\",\"method\":\"GET\",\"url\":\"/.git/config\",\"statusCode\":404,\"durationMs\":6,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"192.99.71.37\",\"ua\":\"Mozilla/5.0 (X11; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0\"}',NULL,'2026-04-07 18:24:18'),('01KNMK23D9S8DK20WYEH0E1XXA','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMK23D8KM8KB1B38F2YP18J\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"116.206.228.188\",\"ua\":\"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Mobile Safari/537.36\"}',NULL,'2026-04-07 18:25:16'),('01KNMK5F2CCWH2XHKFDWH9ZQX4','WARN','GET / 404 (2ms)','{\"requestId\":\"01KNMK5F2AZEDA6R31RJKFMCAX\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:06'),('01KNMK5F7VGPY4ED8H01J4CAYE','WARN','GET //wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5F7S7MX8XKJFZZ0CSQNM\",\"method\":\"GET\",\"url\":\"//wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:06'),('01KNMK5FD82DV9K2X9FR7PN29W','WARN','GET //xmlrpc.php?rsd 404 (1ms)','{\"requestId\":\"01KNMK5FD74VKSDMJGT7H5Y0BH\",\"method\":\"GET\",\"url\":\"//xmlrpc.php?rsd\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //xmlrpc.php</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:06'),('01KNMK5FJQ808RQ6YHAJR59XMD','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMK5FJN7VCJXG635P155AQC\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:06'),('01KNMK5FR4HAFWWW8Z5HJ0T83Z','WARN','GET //blog/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5FR3JFBBA7FMXTXM91Y6\",\"method\":\"GET\",\"url\":\"//blog/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //blog/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:07'),('01KNMK5FXWWMZF3CK55K8JCYJX','WARN','GET //web/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5FXVD85A0S26A2HFP97F\",\"method\":\"GET\",\"url\":\"//web/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //web/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:07'),('01KNMK5G3CDYNJEXHJ43S24VTJ','WARN','GET //wordpress/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5G38N6X0C6TFX3ER9EJK\",\"method\":\"GET\",\"url\":\"//wordpress/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //wordpress/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:07'),('01KNMK5G8WJ28DHEMS4FKGX83W','WARN','GET //website/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5G8VT40DGCVP856THW1S\",\"method\":\"GET\",\"url\":\"//website/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //website/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:07'),('01KNMK5GEEAJCZKQ2BKSQS975N','WARN','GET //wp/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5GED7KTGTF7MY8N2HR7F\",\"method\":\"GET\",\"url\":\"//wp/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //wp/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:07'),('01KNMK5GKXRTWG37WWD1Q2NZV5','WARN','GET //news/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5GKWMSZVWNYS5MRZ2XAD\",\"method\":\"GET\",\"url\":\"//news/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //news/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:08'),('01KNMK5GSRD905PTBQM25AYJ8Z','WARN','GET //2018/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5GSQA063RWBC19BQQ90A\",\"method\":\"GET\",\"url\":\"//2018/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //2018/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:08'),('01KNMK5GZ6B0GP6D33D490S67M','WARN','GET //2019/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5GZ52RAAHYM308K7HSCJ\",\"method\":\"GET\",\"url\":\"//2019/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //2019/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:08'),('01KNMK5H4M2H1666BT1Y50QRB7','WARN','GET //shop/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5H4J8PVJM6W4HJ5JGRDZ\",\"method\":\"GET\",\"url\":\"//shop/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //shop/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:08'),('01KNMK5HA76ZDA8EB6NED0E6N2','WARN','GET //wp1/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5HA5QS3ZQK2237R9PSXQ\",\"method\":\"GET\",\"url\":\"//wp1/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //wp1/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:08'),('01KNMK5HFPGSV9VK0RFVA6VT5B','WARN','GET //test/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5HFM3NJE748RNXP8WS40\",\"method\":\"GET\",\"url\":\"//test/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //test/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:08'),('01KNMK5HN4MA21TETS620E0JJF','WARN','GET //media/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5HN2WETCN7A1N0BSWS57\",\"method\":\"GET\",\"url\":\"//media/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //media/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:09'),('01KNMK5HTQTX5T5SQR8034SC36','WARN','GET //wp2/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5HTPCHC8Q43MAESEE3BJ\",\"method\":\"GET\",\"url\":\"//wp2/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //wp2/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:09'),('01KNMK5J0617VY27AYWNH7J2YC','WARN','GET //site/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5J04QE43N8MNJ994BMW7\",\"method\":\"GET\",\"url\":\"//site/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //site/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:09'),('01KNMK5J5MJ41JG900NVWPEN25','WARN','GET //cms/wp-includes/wlwmanifest.xml 404 (2ms)','{\"requestId\":\"01KNMK5J5JP28ZCNDC1T3B83Q5\",\"method\":\"GET\",\"url\":\"//cms/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //cms/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:09'),('01KNMK5JB2JJSG3X2RD7DEHTMJ','WARN','GET //sito/wp-includes/wlwmanifest.xml 404 (1ms)','{\"requestId\":\"01KNMK5JB0ZTAR4ZQ8WYAXE35Y\",\"method\":\"GET\",\"url\":\"//sito/wp-includes/wlwmanifest.xml\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET //sito/wp-includes/wlwmanifest.xml</pre>\\n</body>\\n</html>\\n\",\"ip\":\"2.58.56.212\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36\"}',NULL,'2026-04-07 18:27:09'),('01KNMKNW0WC7G9QWC5ZPK48YJZ','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMKNW0TRBRZSYMM5XP5SB16\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"34.53.154.149\",\"ua\":\"Mozilla/5.0 (compatible; CMS-Checker/1.0; +https://example.com)\"}',NULL,'2026-04-07 18:36:03'),('01KNMNMXNPJY5MGJ55PZFD904Y','INFO','GET /api/cron/remind-payments 200 (22ms)','{\"requestId\":\"01KNMNMXMY3MXPNZ3YC1AB3GXY\",\"method\":\"GET\",\"url\":\"/api/cron/remind-payments\",\"statusCode\":200,\"durationMs\":22}',NULL,'2026-04-07 19:10:30'),('01KNMNY7NC56F1THVSA4W1EBMH','WARN','GET /api/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php 404 (1ms)','{\"requestId\":\"01KNMNY7NAMW43H1T4T839T58M\",\"method\":\"GET\",\"url\":\"/api/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /api/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php</pre>\\n</body>\\n</html>\\n\",\"ip\":\"149.28.86.228\",\"ua\":\"libredtail-http\"}',NULL,'2026-04-07 19:15:35'),('01KNMNYGAT3YEYE96Y01F3JSVD','WARN','GET /frontend/.git/config 404 (1ms)','{\"requestId\":\"01KNMNYGAR76AQ9B9P6J069N6R\",\"method\":\"GET\",\"url\":\"/frontend/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /frontend/.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"92.118.39.32\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 19:15:44'),('01KNMNYGAYJ41PEREKF182W9NQ','WARN','GET /backend/.git/config 404 (1ms)','{\"requestId\":\"01KNMNYGAWN4CNY12WYDZ0G148\",\"method\":\"GET\",\"url\":\"/backend/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /backend/.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"92.118.39.32\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 19:15:44'),('01KNMNYGBC0F714QQEESNWGHBV','WARN','GET /build/.git/config 404 (1ms)','{\"requestId\":\"01KNMNYGBAA941KSJ12BJVWYVB\",\"method\":\"GET\",\"url\":\"/build/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /build/.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"92.118.39.32\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 19:15:44'),('01KNMNYGBGZDK12DYD5PMSFD25','WARN','GET /wp-content/.git/config 404 (1ms)','{\"requestId\":\"01KNMNYGBFVKMY4N4NHFP2GNJD\",\"method\":\"GET\",\"url\":\"/wp-content/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /wp-content/.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"92.118.39.32\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 19:15:44'),('01KNMNYGBSEJ2XM3BT6HH46F66','WARN','GET /packages/.git/config 404 (1ms)','{\"requestId\":\"01KNMNYGBRZ7WHYA06W5BK2VYC\",\"method\":\"GET\",\"url\":\"/packages/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /packages/.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"92.118.39.32\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 19:15:44'),('01KNMNYGC5DHD7QJJ7KA0JGQD2','WARN','GET /dist/.git/config 404 (1ms)','{\"requestId\":\"01KNMNYGC36SJ4AXW3TYR5M4V8\",\"method\":\"GET\",\"url\":\"/dist/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /dist/.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"92.118.39.32\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 19:15:44'),('01KNMNYGCAYZEXMMV71KBSD088','WARN','GET /public/.git/config 404 (1ms)','{\"requestId\":\"01KNMNYGC9ZKPCNQAXY63JZBD5\",\"method\":\"GET\",\"url\":\"/public/.git/config\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /public/.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"92.118.39.32\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 19:15:44'),('01KNMNYGCF41C0BGQKW7N0A6SW','WARN','GET /modules/.git/config 404 (2ms)','{\"requestId\":\"01KNMNYGCD2CP5AD0AMZ5GWHZ4\",\"method\":\"GET\",\"url\":\"/modules/.git/config\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /modules/.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"92.118.39.32\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 19:15:44'),('01KNMRD0B5XYDA1C5TG5NV2XVH','INFO','GET /api/cron/expire-images 200 (8ms)','{\"requestId\":\"01KNMRD0AWRKRE7PBWSTY024A2\",\"method\":\"GET\",\"url\":\"/api/cron/expire-images\",\"statusCode\":200,\"durationMs\":8}',NULL,'2026-04-07 19:58:36'),('01KNMSK1QCQ79GFR8WWAQ2WMTE','WARN','GET / 404 (1ms)','{\"requestId\":\"01KNMSK1QB022BBVR2X1303TJC\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"45.92.87.187\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36\"}',NULL,'2026-04-07 20:19:22'),('01KNMSK2QH303VRJ6TG4PYCR3T','WARN','GET / 404 (2ms)','{\"requestId\":\"01KNMSK2QFK1Y3GX83FVF3CXD5\",\"method\":\"GET\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"45.92.87.244\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36\"}',NULL,'2026-04-07 20:19:24'),('01KNMV8NZPAD9Q9RKA7T683YMA','WARN','POST / 404 (1ms)','{\"requestId\":\"01KNMV8NZKJZXFSEJZGBTQYJ77\",\"method\":\"POST\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot POST /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"85.11.167.19\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 20:48:40'),('01KNMV8PPX093856HE92J5V1WT','WARN','POST / 404 (12ms)','{\"requestId\":\"01KNMV8PPHHD3ZPQSY42NQK7Z8\",\"method\":\"POST\",\"url\":\"/\",\"statusCode\":404,\"durationMs\":12,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot POST /</pre>\\n</body>\\n</html>\\n\",\"ip\":\"85.11.167.19\",\"ua\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36\"}',NULL,'2026-04-07 20:48:41'),('01KNMVGX2QE5P35R3KXSPX8EQR','INFO','GET /api/cron/reconcile-quota 200 (10ms)','{\"requestId\":\"01KNMVGX2C851F62N0165FXZG2\",\"method\":\"GET\",\"url\":\"/api/cron/reconcile-quota\",\"statusCode\":200,\"durationMs\":10}',NULL,'2026-04-07 20:53:09'),('01KNMVH9RJC5JX6HZ9W1X1T28X','INFO','GET /api/cron/remind-payments 200 (11ms)','{\"requestId\":\"01KNMVH9R6XDZ0HXYFRR253MAM\",\"method\":\"GET\",\"url\":\"/api/cron/remind-payments\",\"statusCode\":200,\"durationMs\":11}',NULL,'2026-04-07 20:53:22'),('01KNMXAVKJZSFS9G2JCW4JCZCP','WARN','GET /api/.git/config 404 (2ms)','{\"requestId\":\"01KNMXAVKGRCWW3FNSJZNG5C7F\",\"method\":\"GET\",\"url\":\"/api/.git/config\",\"statusCode\":404,\"durationMs\":2,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /api/.git/config</pre>\\n</body>\\n</html>\\n\",\"ip\":\"185.177.72.61\",\"ua\":\"l9explore/1.2.2\"}',NULL,'2026-04-07 21:24:48'),('01KNMXB4G6Z88WTWAHNM3DYXV8','WARN','GET /api/.env 404 (1ms)','{\"requestId\":\"01KNMXB4G47V9DCEHQ30DZ88E3\",\"method\":\"GET\",\"url\":\"/api/.env\",\"statusCode\":404,\"durationMs\":1,\"resBody\":\"<!DOCTYPE html>\\n<html lang=\\\"en\\\">\\n<head>\\n<meta charset=\\\"utf-8\\\">\\n<title>Error</title>\\n</head>\\n<body>\\n<pre>Cannot GET /api/.env</pre>\\n</body>\\n</html>\\n\",\"ip\":\"185.177.72.61\",\"ua\":\"l9explore/1.2.2\"}',NULL,'2026-04-07 21:24:57');
/*!40000 ALTER TABLE `app_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guest_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `comments_image_idx` (`image_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `images` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `album_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_key` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumb_key` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preview_key` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `storage_backend` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'r2',
  `drive_file_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_size` bigint NOT NULL,
  `width` int DEFAULT NULL,
  `height` int DEFAULT NULL,
  `status` enum('uploading','processing','ready','failed','syncing') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'uploading',
  `like_count` int NOT NULL DEFAULT '0',
  `comment_count` int NOT NULL DEFAULT '0',
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `images_album_created_idx` (`album_id`,`created_at`),
  KEY `images_user_created_idx` (`user_id`,`created_at`),
  KEY `images_expiry_idx` (`expires_at`,`status`),
  KEY `images_status_idx` (`status`,`created_at`),
  KEY `images_album_like_idx` (`album_id`,`like_count`),
  KEY `images_album_size_idx` (`album_id`,`original_size`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `likes`
--

DROP TABLE IF EXISTS `likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `likes` (
  `user_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`image_id`),
  KEY `likes_image_idx` (`image_id`),
  KEY `likes_user_idx` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likes`
--

LOCK TABLES `likes` WRITE;
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_methods` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('bank_transfer','momo','zalopay','cash') COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `config` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `pm_active_idx` (`is_active`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plan_id` varchar(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addon_bytes` bigint DEFAULT NULL,
  `amount_vnd` int NOT NULL,
  `reference_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method_id` varchar(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','awaiting_confirm','paid','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `customer_note` text COLLATE utf8mb4_unicode_ci,
  `admin_note` text COLLATE utf8mb4_unicode_ci,
  `confirmed_by_user` tinyint(1) NOT NULL DEFAULT '0',
  `confirmed_at` datetime DEFAULT NULL,
  `marked_paid_by` varchar(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_reference_code_unique` (`reference_code`),
  UNIQUE KEY `payments_ref_idx` (`reference_code`),
  KEY `payments_user_idx` (`user_id`,`created_at`),
  KEY `payments_status_idx` (`status`,`created_at`),
  KEY `payments_method_idx` (`payment_method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plans` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_vnd` int NOT NULL DEFAULT '0',
  `duration_days` int NOT NULL,
  `quota_bytes` bigint NOT NULL,
  `max_albums` int DEFAULT NULL,
  `can_download` tinyint(1) NOT NULL DEFAULT '0',
  `can_filter` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit_photo` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `plans_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` VALUES ('01KNM58BJNFACEX2EJ9GTWX9EB','free','Free',0,30,5368709120,5,0,0,0,1,0),('01KNM58BJQED76BKK0BPT341GJ','pro','Pro',499000,365,214748364800,NULL,1,1,1,1,2),('01KNM58BJQR5F2GH5SJ1CV4H3R','basic','Cơ bản',49000,30,53687091200,NULL,1,1,0,1,1);
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referrals`
--

DROP TABLE IF EXISTS `referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referrals` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referrer_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referee_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reward_days` int NOT NULL DEFAULT '7',
  `rewarded` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `referrals_referee_idx` (`referee_id`),
  KEY `referrals_referrer_idx` (`referrer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referrals`
--

LOCK TABLES `referrals` WRITE;
/*!40000 ALTER TABLE `referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `referrals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refresh_tokens`
--

DROP TABLE IF EXISTS `refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refresh_tokens` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refresh_tokens_token_hash_unique` (`token_hash`),
  KEY `refresh_tokens_user_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refresh_tokens`
--

LOCK TABLES `refresh_tokens` WRITE;
/*!40000 ALTER TABLE `refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_changelog`
--

DROP TABLE IF EXISTS `schema_changelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_changelog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(20) NOT NULL COMMENT 'VD: 1.0.0, 1.1.0',
  `filename` varchar(255) NOT NULL COMMENT 'VD: 001__add_column.sql',
  `description` varchar(255) NOT NULL DEFAULT '',
  `applied_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `applied_by` varchar(50) NOT NULL DEFAULT 'ci' COMMENT 'ci hoac manual',
  `checksum` varchar(64) DEFAULT NULL COMMENT 'SHA256 cua file SQL',
  `execution_ms` int DEFAULT NULL COMMENT 'Thoi gian chay (ms)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_version_file` (`version`,`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_changelog`
--

LOCK TABLES `schema_changelog` WRITE;
/*!40000 ALTER TABLE `schema_changelog` DISABLE KEYS */;
INSERT INTO `schema_changelog` VALUES (1,'1.0.0','001__add_storage_backend_columns.sql','add storage backend columns','2026-04-07 14:24:10','ci','5142499d7df443c5b40d1cad3c5982214634c36d647a33e727c5c9305418111f',2486);
/*!40000 ALTER TABLE `schema_changelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_addons`
--

DROP TABLE IF EXISTS `storage_addons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `storage_addons` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bytes` bigint NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `storage_addons_user_idx` (`user_id`,`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage_addons`
--

LOCK TABLES `storage_addons` WRITE;
/*!40000 ALTER TABLE `storage_addons` DISABLE KEYS */;
/*!40000 ALTER TABLE `storage_addons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_snapshots`
--

DROP TABLE IF EXISTS `storage_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `storage_snapshots` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_bytes_private` bigint NOT NULL,
  `total_bytes_public` bigint NOT NULL,
  `total_users` int NOT NULL,
  `total_images` int NOT NULL,
  `total_albums` int NOT NULL,
  `new_users_today` int NOT NULL DEFAULT '0',
  `revenue_today` int NOT NULL DEFAULT '0',
  `visit_count` int NOT NULL DEFAULT '0',
  `snapshot_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `storage_snapshots_time_idx` (`snapshot_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage_snapshots`
--

LOCK TABLES `storage_snapshots` WRITE;
/*!40000 ALTER TABLE `storage_snapshots` DISABLE KEYS */;
INSERT INTO `storage_snapshots` VALUES ('01KNM7CZECX9TD4VEQDWVYZN0R',0,0,1,0,0,1,0,0,'2026-04-07 15:01:29'),('01KNMATV186Z24VW397W84YW7A',0,0,1,0,0,1,0,0,'2026-04-07 16:01:29'),('01KNME8PSA83QKTQXD4ZM1NHQ7',0,0,1,0,0,1,0,0,'2026-04-07 17:01:29'),('01KNMHPJ9WR2DXD1K56CVA3M5V',0,0,1,0,0,1,0,0,'2026-04-07 18:01:29'),('01KNMN4DWFZB710JZNNB9SXRZ3',0,0,1,0,0,1,0,0,'2026-04-07 19:01:29'),('01KNMRJ9GRWT8G3RP096PZP1VF',0,0,1,0,0,1,0,0,'2026-04-07 20:01:29'),('01KNMW055YNV2NQRCK7M6K13FC',0,0,1,0,0,1,0,0,'2026-04-07 21:01:29');
/*!40000 ALTER TABLE `storage_snapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` varchar(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES ('admin_email','buihongquan28041997@gmail.com','2026-04-07 14:24:00',NULL),('admin_name','BHQuan','2026-04-07 14:24:00',NULL),('allowed_mime_types','[\"image/x-canon-cr2\",\"image/x-sony-arw\",\"image/x-nikon-nef\",\"image/x-adobe-dng\",\"image/jpeg\",\"image/png\",\"image/tiff\"]','2026-04-07 14:24:00',NULL),('app_address','Vietnam','2026-04-07 14:24:00',NULL),('app_developer','BHQuan','2026-04-07 14:24:00',NULL),('contact_messenger','','2026-04-07 14:24:00',NULL),('contact_zalo','','2026-04-07 14:24:00',NULL),('debug_mode','false','2026-04-07 14:24:00',NULL),('image_error_spike_threshold','20','2026-04-07 14:24:00',NULL),('local_storage_dir','./data/storage','2026-04-07 14:24:00',NULL),('log_retention_days','30','2026-04-07 14:24:00',NULL),('max_upload_size_mb','200','2026-04-07 14:24:00',NULL),('registration_open','true','2026-04-07 14:24:00',NULL),('storage_alert_threshold_percent','80','2026-04-07 14:24:00',NULL),('storage_backend','r2','2026-04-07 14:24:00',NULL),('worker_stuck_minutes','30','2026-04-07 14:24:00',NULL);
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_plans`
--

DROP TABLE IF EXISTS `user_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_plans` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plan_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `granted_by` varchar(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `started_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `user_plans_user_active_idx` (`user_id`,`is_active`),
  KEY `user_plans_expiry_idx` (`expires_at`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_plans`
--

LOCK TABLES `user_plans` WRITE;
/*!40000 ALTER TABLE `user_plans` DISABLE KEYS */;
INSERT INTO `user_plans` VALUES ('01KNM58BST2K8B5C5HVTWJMYMZ','01KNM58BMQZ4B0PEFEF7X0DHVV','01KNM58BJQED76BKK0BPT341GJ',NULL,'2026-04-07 14:24:01','2027-04-07 14:24:01',1);
/*!40000 ALTER TABLE `user_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar_key` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `role` enum('user','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `email_verified` tinyint(1) NOT NULL DEFAULT '0',
  `referral_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referred_by` varchar(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_email_idx` (`email`),
  UNIQUE KEY `users_referral_code_idx` (`referral_code`),
  KEY `users_role_idx` (`role`,`is_active`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('01KNM58BMQZ4B0PEFEF7X0DHVV','admin@photostorage.com','$2b$10$iv5Lh/k3JfyavvZ9TZd6nOz77sSigGfgxzLjKmn14th9ATtlmC/Uq','Admin',NULL,NULL,'admin',1,1,NULL,NULL,'2026-04-07 14:24:00','2026-04-07 14:24:00');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voucher_usages`
--

DROP TABLE IF EXISTS `voucher_usages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voucher_usages` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `voucher_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `used_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `voucher_usages_voucher_idx` (`voucher_id`),
  KEY `voucher_usages_user_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voucher_usages`
--

LOCK TABLES `voucher_usages` WRITE;
/*!40000 ALTER TABLE `voucher_usages` DISABLE KEYS */;
/*!40000 ALTER TABLE `voucher_usages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vouchers`
--

DROP TABLE IF EXISTS `vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vouchers` (
  `id` varchar(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('plan_activation','addon_storage','addon_days') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'plan_activation',
  `plan_id` varchar(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_days` int NOT NULL DEFAULT '30',
  `addon_bytes` bigint DEFAULT NULL,
  `max_uses` int DEFAULT NULL,
  `used_count` int NOT NULL DEFAULT '0',
  `valid_from` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `valid_until` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` varchar(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vouchers_code_unique` (`code`),
  UNIQUE KEY `vouchers_code_idx` (`code`),
  KEY `vouchers_active_idx` (`is_active`,`valid_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vouchers`
--

LOCK TABLES `vouchers` WRITE;
/*!40000 ALTER TABLE `vouchers` DISABLE KEYS */;
/*!40000 ALTER TABLE `vouchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'photo_storage'
--

--
-- Dumping routines for database 'photo_storage'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-07 21:41:02
